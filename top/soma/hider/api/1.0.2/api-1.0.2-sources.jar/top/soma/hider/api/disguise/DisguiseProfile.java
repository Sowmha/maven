package top.soma.hider.api.disguise;

import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;

/**
 * What a hidden player looks like. Build one with {@link #builder()}, or read one from a
 * config section layered over a base default with {@link #fromSection(ConfigurationSection, DisguiseProfile)}.
 */
public record DisguiseProfile(boolean showName, boolean showHealth, String namePrefix, boolean showArmor, boolean showFire, boolean showStuckArrows, boolean showCape, boolean showNbts) {

    public DisguiseProfile {
        namePrefix = namePrefix == null ? "" : namePrefix;
    }

    /** Everything shown (a fake name, health, armor, effects); the neutral baseline. */
    public static DisguiseProfile defaults() {
        return builder().build();
    }

    /**
     * Reads a disguise from a config section, falling back to {@code defaults} for every
     * key the section omits: only the keys present override.
     * Keys: {@code show_name}, {@code show_health}, {@code show_armor}, {@code show_fire},
     * {@code show_stuck_arrows}, {@code show_cape}, {@code show_nbts}, {@code prefix} (supports {@code &} colors).
     */
    public static DisguiseProfile fromSection(ConfigurationSection section, DisguiseProfile defaults) {
        if (section == null) {
            return defaults;
        }
        String prefix = section.isString("prefix")
                ? ChatColor.translateAlternateColorCodes('&', section.getString("prefix"))
                : defaults.namePrefix();
        return builder()
                .showName(section.getBoolean("show_name", defaults.showName()))
                .showHealth(section.getBoolean("show_health", defaults.showHealth()))
                .namePrefix(prefix)
                .showArmor(section.getBoolean("show_armor", defaults.showArmor()))
                .showFire(section.getBoolean("show_fire", defaults.showFire()))
                .showStuckArrows(section.getBoolean("show_stuck_arrows", defaults.showStuckArrows()))
                .showCape(section.getBoolean("show_cape", defaults.showCape()))
                .showNbts(section.getBoolean("show_nbts", defaults.showNbts()))
                .build();
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {

        private boolean showName = true;
        private boolean showHealth = true;
        private String namePrefix = "";
        private boolean showArmor = true;
        private boolean showFire = true;
        private boolean showStuckArrows = true;
        private boolean showCape = true;
        private boolean showNbts = true;

        private Builder() {
        }

        public Builder showName(boolean showName) {
            this.showName = showName;
            return this;
        }

        public Builder showHealth(boolean showHealth) {
            this.showHealth = showHealth;
            return this;
        }

        public Builder namePrefix(String namePrefix) {
            this.namePrefix = namePrefix;
            return this;
        }

        public Builder showArmor(boolean showArmor) {
            this.showArmor = showArmor;
            return this;
        }

        public Builder showFire(boolean showFire) {
            this.showFire = showFire;
            return this;
        }

        public Builder showStuckArrows(boolean showStuckArrows) {
            this.showStuckArrows = showStuckArrows;
            return this;
        }

        public Builder showCape(boolean showCape) {
            this.showCape = showCape;
            return this;
        }

        public Builder showNbts(boolean showNbts) {
            this.showNbts = showNbts;
            return this;
        }

        public DisguiseProfile build() {
            return new DisguiseProfile(showName, showHealth, namePrefix, showArmor, showFire, showStuckArrows, showCape, showNbts);
        }
    }
}
