package top.soma.hider.api;

import java.util.Collection;

import top.soma.hider.api.zone.HiderZone;
import top.soma.hider.api.zone.Region;
import top.soma.hider.api.zone.ZoneBuilder;

/**
 * Entry point for hiding players inside zones.
 *
 * <pre>{@code
 * HiderZone zone = SomaHiderProvider.get()
 *         .hide(arena::contains)
 *         .groupResolver(player -> factionId(player))
 *         .reveal(Reveal.sameGroup())
 *         .open();
 * // ...later
 * zone.close();
 * }</pre>
 */
public interface SomaHider {

    /** Begins a zone that covers the whole server. */
    ZoneBuilder hide();

    /** Begins a zone bounded by {@code region}. */
    ZoneBuilder hide(Region region);

    /** A snapshot of the currently open zones. */
    Collection<HiderZone> zones();
}
