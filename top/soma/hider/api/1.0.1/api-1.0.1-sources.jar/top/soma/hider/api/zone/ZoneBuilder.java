package top.soma.hider.api.zone;

import java.time.Duration;

import org.bukkit.configuration.ConfigurationSection;

import top.soma.hider.api.disguise.DisguiseProfile;
import top.soma.hider.api.hook.GroupResolver;
import top.soma.hider.api.rule.VisibilityRule;

/**
 * Fluent description of a zone. Terminal call is {@link #open()}.
 *
 * <p>A target inside the zone is revealed to a viewer when <em>any</em> of the supplied
 * reveal rules matches; with no rule, the target is hidden from everyone.
 */
public interface ZoneBuilder {

    /** Optional name (defaults to an auto-generated one). */
    ZoneBuilder named(String name);

    /** Look applied to hidden players. Defaults to the plugin's configured disguise. */
    ZoneBuilder disguise(DisguiseProfile disguise);

    /**
     * Look applied to hidden players, read from a config section and layered over the
     * plugin's configured default: only keys present in the section override it.
     */
    ZoneBuilder disguise(ConfigurationSection section);

    /** Auto-close the zone after this delay. */
    ZoneBuilder duration(Duration duration);

    /**
     * How players map to a group id for this zone's group-based reveal rules
     * (e.g. {@link top.soma.hider.api.rule.Reveal#sameGroup()}). Scoped to the zone, so
     * different consumers never collide; {@code null} groups never match.
     */
    ZoneBuilder groupResolver(GroupResolver resolver);

    /** Reveal rules combined with OR. Call with none for "nobody is visible". */
    ZoneBuilder reveal(VisibilityRule... rules);

    /** Opens the zone and returns its handle. */
    HiderZone open();
}
