package top.soma.hider.api.rule;

import org.bukkit.entity.Player;

/**
 * Per-evaluation view passed to rules. You only need it when writing a custom rule
 * that reasons about groups; the {@link Reveal} factories use it for you.
 */
public interface RuleContext {

    /** The group id of {@code player} (as produced by the configured group resolver), or {@code null}. */
    String groupOf(Player player);
}
