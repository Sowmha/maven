package top.soma.hider.api.hook;

import org.bukkit.entity.Player;

@FunctionalInterface
public interface GroupResolver {

    String groupOf(Player player);
}
