package top.soma.hider.api.disguise;

import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;

/**
 * What a hidden player looks like. Build one with {@link #builder()}, read one from
 * config with {@link #fromSection(ConfigurationSection)}, or take {@link #hidden()} /
 * {@link #defaults()}.
 */
public record DisguiseProfile(boolean showName, boolean showHealth, String namePrefix, boolean showArmor, boolean showFire, boolean showStuckArrows, boolean showCape) {

    public DisguiseProfile {
        namePrefix = namePrefix == null ? "" : namePrefix;
    }

    /** Everything shown (a fake name, health, armor, effects). */
    public static DisguiseProfile defaults() {
        return builder().build();
    }

    /** Strong hide: no name, armor and effects stripped, health kept. */
    public static DisguiseProfile hidden() {
        return builder()
                .showName(false)
                .showArmor(false)
                .showFire(false)
                .showStuckArrows(false)
                .showCape(false)
                .build();
    }

    /**
     * Reads a disguise from a config section, defaulting to {@link #hidden()} for any
     * missing key (so an empty {@code hider:} block already hides hard). Keys:
     * {@code show-name}, {@code show-health}, {@code show-armor}, {@code show-fire},
     * {@code show-stuck-arrows}, {@code show-cape}, {@code prefix} (supports {@code &} colors).
     */
    public static DisguiseProfile fromSection(ConfigurationSection section) {
        if (section == null) {
            return hidden();
        }
        return builder()
                .showName(section.getBoolean("show-name", false))
                .showHealth(section.getBoolean("show-health", true))
                .namePrefix(ChatColor.translateAlternateColorCodes('&', section.getString("prefix", "")))
                .showArmor(section.getBoolean("show-armor", false))
                .showFire(section.getBoolean("show-fire", false))
                .showStuckArrows(section.getBoolean("show-stuck-arrows", false))
                .showCape(section.getBoolean("show-cape", false))
                .build();
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {

        private boolean showName = true;
        private boolean showHealth = true;
        private String namePrefix = "";
        private boolean showArmor = true;
        private boolean showFire = true;
        private boolean showStuckArrows = true;
        private boolean showCape = true;

        private Builder() {
        }

        public Builder showName(boolean showName) {
            this.showName = showName;
            return this;
        }

        public Builder showHealth(boolean showHealth) {
            this.showHealth = showHealth;
            return this;
        }

        public Builder namePrefix(String namePrefix) {
            this.namePrefix = namePrefix;
            return this;
        }

        public Builder showArmor(boolean showArmor) {
            this.showArmor = showArmor;
            return this;
        }

        public Builder showFire(boolean showFire) {
            this.showFire = showFire;
            return this;
        }

        public Builder showStuckArrows(boolean showStuckArrows) {
            this.showStuckArrows = showStuckArrows;
            return this;
        }

        public Builder showCape(boolean showCape) {
            this.showCape = showCape;
            return this;
        }

        public DisguiseProfile build() {
            return new DisguiseProfile(showName, showHealth, namePrefix, showArmor, showFire, showStuckArrows, showCape);
        }
    }
}
