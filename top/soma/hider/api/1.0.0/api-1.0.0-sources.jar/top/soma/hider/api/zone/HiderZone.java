package top.soma.hider.api.zone;

/** Handle to an open zone. Call {@link #close()} to take it down. */
public interface HiderZone {

    String name();

    Region region();

    void close();
}
