package top.soma.hider.api;

public final class SomaHiderProvider {

    private static SomaHider instance;

    private SomaHiderProvider() {
        throw new UnsupportedOperationException("You can't instantiate this class.");
    }

    public static void register(SomaHider hider) {
        if (instance != null) {
            throw new IllegalStateException("SomaHider is already registered.");
        }
        instance = hider;
    }

    public static void unregister() {
        instance = null;
    }

    public static SomaHider get() {
        if (instance == null) {
            throw new IllegalStateException("SomaHider is not loaded yet. Install SomaHider as a plugin, or register an instance in your plugin's onEnable.");
        }
        return instance;
    }

    public static boolean isAvailable() {
        return instance != null;
    }
}
