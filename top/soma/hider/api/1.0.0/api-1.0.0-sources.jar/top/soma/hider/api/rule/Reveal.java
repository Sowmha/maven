package top.soma.hider.api.rule;

import java.util.Collection;
import java.util.Objects;
import java.util.function.BiPredicate;
import java.util.function.Supplier;

import org.bukkit.entity.Player;

/**
 * Ready-made {@link VisibilityRule}s. Combine them with {@code or}/{@code and}/{@code negate}:
 * <pre>{@code
 * Reveal.sameGroup().or(Reveal.group(() -> capturingFactionId))
 * }</pre>
 */
public final class Reveal {

    private Reveal() {
        throw new UnsupportedOperationException("You can't instantiate this class.");
    }

    /** Reveal a target that shares the viewer's group. */
    public static VisibilityRule sameGroup() {
        return (viewer, target, context) -> {
            String group = context.groupOf(viewer);
            return group != null && group.equals(context.groupOf(target));
        };
    }

    /** Reveal every member of {@code groupId} to everyone. */
    public static VisibilityRule group(String groupId) {
        Objects.requireNonNull(groupId, "groupId");
        return (viewer, target, context) -> groupId.equals(context.groupOf(target));
    }

    /** Reveal every member of the (live) group to everyone — the supplier is read each evaluation. */
    public static VisibilityRule group(Supplier<String> groupId) {
        Objects.requireNonNull(groupId, "groupId");
        return (viewer, target, context) -> {
            String id = groupId.get();
            return id != null && id.equals(context.groupOf(target));
        };
    }

    /** Reveal members of the (live) set of groups to one another — viewer and target must both be in it. */
    public static VisibilityRule groupsTogether(Supplier<? extends Collection<String>> groups) {
        Objects.requireNonNull(groups, "groups");
        return (viewer, target, context) -> {
            Collection<String> ids = groups.get();
            if (ids == null || ids.isEmpty()) {
                return false;
            }
            String viewerGroup = context.groupOf(viewer);
            String targetGroup = context.groupOf(target);
            return viewerGroup != null && targetGroup != null && ids.contains(viewerGroup) && ids.contains(targetGroup);
        };
    }

    /** Reveal everyone to viewers holding {@code node}. */
    public static VisibilityRule permission(String node) {
        Objects.requireNonNull(node, "node");
        return (viewer, target, context) -> viewer.hasPermission(node);
    }

    /** Escape hatch: any predicate over (viewer, target). */
    public static VisibilityRule of(BiPredicate<Player, Player> predicate) {
        Objects.requireNonNull(predicate, "predicate");
        return (viewer, target, context) -> predicate.test(viewer, target);
    }

    public static VisibilityRule always() {
        return (viewer, target, context) -> true;
    }

    public static VisibilityRule never() {
        return (viewer, target, context) -> false;
    }
}
