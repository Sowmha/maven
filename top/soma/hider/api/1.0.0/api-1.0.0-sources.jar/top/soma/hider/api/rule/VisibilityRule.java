package top.soma.hider.api.rule;

import org.bukkit.entity.Player;

/**
 * Decides whether {@code target} is revealed (shown as themselves) to {@code viewer}
 * inside a zone. Build rules with {@link Reveal} and compose them with
 * {@link #or}, {@link #and} and {@link #negate}.
 */
@FunctionalInterface
public interface VisibilityRule {

    boolean reveals(Player viewer, Player target, RuleContext context);

    default VisibilityRule or(VisibilityRule other) {
        return (viewer, target, context) -> reveals(viewer, target, context) || other.reveals(viewer, target, context);
    }

    default VisibilityRule and(VisibilityRule other) {
        return (viewer, target, context) -> reveals(viewer, target, context) && other.reveals(viewer, target, context);
    }

    default VisibilityRule negate() {
        return (viewer, target, context) -> !reveals(viewer, target, context);
    }
}
