package top.soma.hider.api.zone;

import org.bukkit.Location;

/**
 * The volume a zone covers. It is a {@link FunctionalInterface}, so any
 * {@code boolean contains(Location)} method reference works as a region —
 * e.g. {@code arena::isInArea}.
 */
@FunctionalInterface
public interface Region {

    boolean contains(Location location);

    /** A region that covers every location. */
    static Region everywhere() {
        return location -> true;
    }

    /** A horizontal disc of {@code radius} centered on {@code center} (ignores Y). */
    static Region circle(Location center, double radius) {
        return new CircleRegion(center, radius);
    }
}
