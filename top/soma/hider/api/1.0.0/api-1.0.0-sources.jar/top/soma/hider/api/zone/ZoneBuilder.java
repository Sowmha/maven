package top.soma.hider.api.zone;

import java.time.Duration;

import top.soma.hider.api.disguise.DisguiseProfile;
import top.soma.hider.api.rule.VisibilityRule;

/**
 * Fluent description of a zone. Terminal call is {@link #open()}.
 *
 * <p>A target inside the zone is revealed to a viewer when <em>any</em> of the supplied
 * reveal rules matches; with no rule, the target is hidden from everyone.
 */
public interface ZoneBuilder {

    /** Optional name (defaults to an auto-generated one); handy for lookup and logs. */
    ZoneBuilder named(String name);

    /** Look applied to hidden players. Defaults to the plugin's configured disguise. */
    ZoneBuilder disguise(DisguiseProfile disguise);

    /** Auto-close the zone after this delay. */
    ZoneBuilder duration(Duration duration);

    /** Reveal rules combined with OR. Call with none for "nobody is visible". */
    ZoneBuilder reveal(VisibilityRule... rules);

    /** Opens the zone and returns its handle. */
    HiderZone open();
}
