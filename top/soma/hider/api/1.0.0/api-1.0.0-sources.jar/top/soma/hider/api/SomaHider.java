package top.soma.hider.api;

import java.util.Collection;

import top.soma.hider.api.hook.GroupResolver;
import top.soma.hider.api.zone.HiderZone;
import top.soma.hider.api.zone.Region;
import top.soma.hider.api.zone.ZoneBuilder;

/**
 * Entry point for hiding players inside zones.
 *
 * <p>Configure the group source once (a "group" is whatever you key visibility on: a faction, a team, a party):
 * <pre>{@code
 * SomaHider hider = SomaHiderProvider.get().groupResolver(player -> factionId(player));
 * }</pre>
 *
 * <p>Then open a zone wherever you need it:
 * <pre>{@code
 * HiderZone zone = hider.hide(arena::contains)
 *         .reveal(Reveal.sameGroup())
 *         .open();
 * // ...later
 * zone.close();
 * }</pre>
 */
public interface SomaHider {

    /**
     * Sets how a player maps to a group id (e.g. a faction id), used by the group-based
     * reveal rules. Returns {@code this} for chaining. {@code null} groups never match.
     */
    SomaHider groupResolver(GroupResolver resolver);

    /** Begins a zone that covers the whole server. */
    ZoneBuilder hide();

    /** Begins a zone bounded by {@code region}. */
    ZoneBuilder hide(Region region);

    /** A snapshot of the currently open zones. */
    Collection<HiderZone> zones();
}
