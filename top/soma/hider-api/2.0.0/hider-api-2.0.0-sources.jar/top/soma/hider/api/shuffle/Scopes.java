package top.soma.hider.api.shuffle;

import org.bukkit.entity.Player;

import top.soma.hider.api.rule.RuleContext;

enum Scopes implements ShuffleScope {
    SHARED {
        @Override
        public String audienceOf(Player viewer, RuleContext context) {
            return "";
        }
    },
    PER_GROUP {
        @Override
        public String audienceOf(Player viewer, RuleContext context) {
            String group = context.groupOf(viewer);
            return group == null ? "" : "group:" + group;
        }
    },
    PER_VIEWER {
        @Override
        public String audienceOf(Player viewer, RuleContext context) {
            return "viewer:" + viewer.getUniqueId();
        }
    }
}
