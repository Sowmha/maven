package top.soma.hider.api.shuffle;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;

/**
 * One assignment of identities to the members of a group, seen by one audience. Members and
 * identities are player UUIDs; an identity always belongs to a member of the group.
 *
 * <p>Changes go through {@link top.soma.hider.api.event.ShuffleDrawEvent} like the plugin's own
 * draws, and must be made from the main thread.
 */
public interface ShuffleDraw {

    ShuffleGroup group();

    /** Audience key of the viewers who see this draw (see {@link ShuffleScope}). */
    String audience();

    /** Member to worn identity, for every member holding a lease. */
    Map<UUID, UUID> leases();

    /** Identity worn by this member, or {@code null} without a lease. */
    UUID identityOf(UUID member);

    /** Member wearing this identity, or {@code null} when nobody wears it. */
    UUID wearerOf(UUID identity);

    /** Gives this identity to the member; whoever wore it takes the member's previous one. */
    void assign(UUID member, UUID identity);

    /** Exchanges the identities of two members holding a lease. */
    void swap(UUID first, UUID second);

    /** Sets these leases at once. Any other member whose identity is taken here draws a free one. */
    void apply(Map<UUID, UUID> leases);

    /** Draws every lease again, pinned ones excepted. */
    void redraw();

    /** Draws every lease again, except pinned ones and those of the given members. */
    void redraw(Collection<UUID> kept);

    /** A pinned lease never moves on a redraw or a repair, unless its identity leaves the group. */
    void pin(UUID member, boolean pinned);

    boolean pinned(UUID member);
}
