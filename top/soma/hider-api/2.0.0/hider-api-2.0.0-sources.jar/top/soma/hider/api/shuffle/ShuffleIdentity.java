package top.soma.hider.api.shuffle;

import java.util.UUID;

/** A member as others can wear him: his real UUID and name. */
public record ShuffleIdentity(UUID uuid, String name) {
}
