package top.soma.hider.api.event;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import top.soma.hider.api.zone.HiderZone;

/**
 * Fired on the main thread after a zone opened, whatever opened it. The players already inside follow on
 * the next visibility pass, each with a {@link PlayerEnterZoneEvent}. A zone opened from another thread is
 * announced on the next tick.
 */
public final class ZoneOpenEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();

    /** What opened the zone. */
    public enum Cause {
        /** A staff command: {@code /sh start} or {@code /sh temp}. */
        COMMAND,
        /** The zone's weekly schedule. */
        SCHEDULE,
        /** One of the zone's chat triggers. */
        CHAT,
        /** {@code always_on}, when the plugin enables or reloads its configuration. */
        ALWAYS_ON,
        /** {@code /sh reload} restarted the zone because its definition changed. */
        RELOAD,
        /** A plugin, through the API. */
        API
    }

    private final HiderZone zone;
    private final Cause cause;

    public ZoneOpenEvent(HiderZone zone, Cause cause) {
        this.zone = zone;
        this.cause = cause;
    }

    /** The zone that opened, a {@link top.soma.hider.api.shuffle.ShuffleZone} when it shuffles. */
    public HiderZone getZone() {
        return zone;
    }

    public Cause getCause() {
        return cause;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
