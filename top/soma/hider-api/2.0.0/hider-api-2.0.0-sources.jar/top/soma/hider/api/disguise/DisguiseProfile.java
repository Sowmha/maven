package top.soma.hider.api.disguise;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;

/**
 * What a hidden player looks like. Build one with {@link #builder()}, or read one from a
 * config section layered over a base default with {@link #fromSection(ConfigurationSection, DisguiseProfile)}.
 *
 * <p>Name and skin sources are declarative values sharing one grammar: {@link #RANDOM}
 * picks from the {@code default} pool, the name of a configured pool picks from that pool,
 * a {@code %placeholder%} is resolved on the hidden player, and anything else is used
 * literally (a fixed name, a skins.yml entry key or a player username).
 */
public record DisguiseProfile(NameSpec name, String skin, HealthSpec health, boolean showArmor, boolean showFire, boolean showStuckArrows, boolean showNbts, boolean showInvisibility) {

    /** Source value picking a random entry from the {@code default} pool. */
    public static final String RANDOM = "random";

    /** Pool used by {@link #RANDOM}; pools cannot be named {@code random}. */
    public static final String DEFAULT_POOL = "default";

    public DisguiseProfile {
        name = name != null ? name : new NameSpec(true, null, null, null);
        skin = skin == null || skin.isBlank() ? RANDOM : skin.trim();
        health = health != null ? health : new HealthSpec(true, null);
    }

    /** A profile that turns invisible along with the hidden player, as every profile did before {@link #showInvisibility()}. */
    public DisguiseProfile(NameSpec name, String skin, HealthSpec health, boolean showArmor, boolean showFire, boolean showStuckArrows, boolean showNbts) {
        this(name, skin, health, showArmor, showFire, showStuckArrows, showNbts, true);
    }

    /** Everything shown (a random name and skin, health, armor, effects); the neutral baseline. */
    public static DisguiseProfile defaults() {
        return builder().build();
    }

    /**
     * Reads a disguise from a config section, falling back to {@code defaults} for every
     * key the section omits: only the keys present override, leaf by leaf.
     *
     * <p>Keys: {@code name} ({@code show}, {@code value}, {@code prefix}, {@code suffix}),
     * {@code skin} (a scalar source value), {@code health} ({@code show}, {@code color} as
     * one code or a list), {@code show_armor}, {@code show_fire}, {@code show_stuck_arrows},
     * {@code show_nbts}, {@code show_invisibility}. Texts support {@code &} colors.
     */
    public static DisguiseProfile fromSection(ConfigurationSection section, DisguiseProfile defaults) {
        if (section == null) return defaults;

        return new DisguiseProfile(
                readName(section.getConfigurationSection("name"), defaults.name()),
                section.isString("skin") ? section.getString("skin") : defaults.skin(),
                readHealth(section.getConfigurationSection("health"), defaults.health()),
                section.getBoolean("show_armor", defaults.showArmor()),
                section.getBoolean("show_fire", defaults.showFire()),
                section.getBoolean("show_stuck_arrows", defaults.showStuckArrows()),
                section.getBoolean("show_nbts", defaults.showNbts()),
                section.getBoolean("show_invisibility", defaults.showInvisibility())
        );
    }

    /** True when {@code value} is a {@code %placeholder%} to resolve through PlaceholderAPI. */
    public static boolean isPlaceholder(String value) {
        return value.length() > 2 && value.startsWith("%") && value.endsWith("%");
    }

    /** True when {@code value} is the {@link #RANDOM} keyword. */
    public static boolean isRandom(String value) {
        return RANDOM.equalsIgnoreCase(value);
    }

    private static NameSpec readName(ConfigurationSection name, NameSpec defaults) {
        if (name == null) return defaults;

        return new NameSpec(
                name.getBoolean("show", defaults.show()),
                name.isString("value") ? name.getString("value") : defaults.value(),
                name.isString("prefix") ? colored(name.getString("prefix")) : defaults.prefix(),
                name.isString("suffix") ? colored(name.getString("suffix")) : defaults.suffix()
        );
    }

    private static HealthSpec readHealth(ConfigurationSection health, HealthSpec defaults) {
        if (health == null) return defaults;

        List<String> colors = defaults.colors();
        if (health.isList("color")) {
            List<String> read = new ArrayList<>();
            for (String color : health.getStringList("color")) {
                read.add(colored(color));
            }
            if (!read.isEmpty()) {
                colors = read;
            }
        } else if (health.isString("color")) {
            colors = List.of(colored(health.getString("color")));
        }
        return new HealthSpec(health.getBoolean("show", defaults.show()), colors);
    }

    private static String colored(String text) {
        return text == null ? "" : ChatColor.translateAlternateColorCodes('&', text);
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {

        private NameSpec name = new NameSpec(true, null, null, null);
        private String skin = RANDOM;
        private HealthSpec health = new HealthSpec(true, null);
        private boolean showArmor = true;
        private boolean showFire = true;
        private boolean showStuckArrows = true;
        private boolean showNbts = true;
        private boolean showInvisibility = true;

        private Builder() {}

        public Builder name(NameSpec name) {
            this.name = name;
            return this;
        }

        public Builder skin(String skin) {
            this.skin = skin;
            return this;
        }

        public Builder health(HealthSpec health) {
            this.health = health;
            return this;
        }

        public Builder showArmor(boolean showArmor) {
            this.showArmor = showArmor;
            return this;
        }

        public Builder showFire(boolean showFire) {
            this.showFire = showFire;
            return this;
        }

        public Builder showStuckArrows(boolean showStuckArrows) {
            this.showStuckArrows = showStuckArrows;
            return this;
        }

        public Builder showNbts(boolean showNbts) {
            this.showNbts = showNbts;
            return this;
        }

        public Builder showInvisibility(boolean showInvisibility) {
            this.showInvisibility = showInvisibility;
            return this;
        }

        public DisguiseProfile build() {
            return new DisguiseProfile(name, skin, health, showArmor, showFire, showStuckArrows, showNbts, showInvisibility);
        }
    }
}
