package top.soma.hider.api.rule;

import java.util.function.Supplier;

import org.bukkit.entity.Player;

/**
 * Per-evaluation view passed to rules. You only need it when writing a custom rule
 * that reasons about groups; the {@link Reveal} factories use it for you.
 */
public interface RuleContext {

    /** The group id of {@code player} (as produced by the configured group resolver), or {@code null}. */
    String groupOf(Player player);

    boolean hasPermission(Player viewer, String node);

    /**
     * Evaluates {@code supplier} at most once per pass, then hands the same value to every other
     * pair evaluated in that pass. Reach for it whenever a rule reads something costly that does
     * not depend on the viewer or the target, such as a live standings table: a rule runs once per
     * (viewer, target) couple, so an unguarded lookup there is paid thousands of times per second.
     * Keyed on the supplier instance, so hold on to it rather than building a new lambda per call.
     */
    default <T> T once(Supplier<T> supplier) {
        return supplier.get();
    }
}
