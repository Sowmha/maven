package top.soma.hider.api.disguise;

import java.util.List;

import org.bukkit.ChatColor;

/**
 * The health shown next to a hidden player's name.
 *
 * @param show   false hides the hearts
 * @param colors legacy color codes for the heart symbol; one entry is a fixed color,
 *               several mean one is picked at random per disguise
 */
public record HealthSpec(boolean show, List<String> colors) {

    public HealthSpec {
        colors = colors == null || colors.isEmpty() ? List.of(ChatColor.DARK_RED.toString()) : List.copyOf(colors);
    }
}
