package top.soma.hider.api.event;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import top.soma.hider.api.zone.HiderZone;

/**
 * Fired on the main thread after a zone closed, whatever closed it. The players it covered then leave it,
 * each with a {@link PlayerLeaveZoneEvent} of cause {@link PlayerLeaveZoneEvent.Cause#ZONE_CLOSED}. A zone
 * closed from another thread is announced on the next tick.
 */
public final class ZoneCloseEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();

    /** What closed the zone. */
    public enum Cause {
        /** A staff command: {@code /sh stop}. */
        COMMAND,
        /** The end of a slot of the zone's weekly schedule. */
        SCHEDULE,
        /** The zone's stop trigger in chat. */
        CHAT,
        /** The zone's duration elapsed. */
        EXPIRED,
        /** {@code /sh reload} removed the zone, or restarted it because its definition changed. */
        RELOAD,
        /** A plugin, through {@link HiderZone#close()}. */
        API,
        /** SomaHider is being disabled. */
        SHUTDOWN
    }

    private final HiderZone zone;
    private final Cause cause;

    public ZoneCloseEvent(HiderZone zone, Cause cause) {
        this.zone = zone;
        this.cause = cause;
    }

    /** The zone that closed, a {@link top.soma.hider.api.shuffle.ShuffleZone} when it shuffled. */
    public HiderZone getZone() {
        return zone;
    }

    public Cause getCause() {
        return cause;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
