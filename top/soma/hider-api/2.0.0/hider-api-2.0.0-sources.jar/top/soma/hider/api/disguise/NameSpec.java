package top.soma.hider.api.disguise;

/**
 * The name shown above a hidden player's head.
 *
 * @param show   false hides the name entirely (hearts may still show through {@link HealthSpec})
 * @param value  {@link DisguiseProfile#RANDOM}, a usernames.yml pool name, a literal name,
 *               or a {@code %placeholder%} resolved on the hidden player
 * @param prefix text before the name; supports {@code &} colors and placeholders,
 *               including relational {@code %rel_...%} ones resolved per viewer
 * @param suffix text after the name, same rules as {@code prefix}
 */
public record NameSpec(boolean show, String value, String prefix, String suffix) {

    public NameSpec {
        value = value == null || value.isBlank() ? DisguiseProfile.RANDOM : value.trim();
        prefix = prefix == null ? "" : prefix;
        suffix = suffix == null ? "" : suffix;
    }

    /** True when {@link #value()} is the {@link DisguiseProfile#RANDOM} keyword. */
    public boolean random() {
        return DisguiseProfile.isRandom(value);
    }

    /** True when {@link #value()} is a placeholder resolved on the hidden player. */
    public boolean placeholder() {
        return DisguiseProfile.isPlaceholder(value);
    }
}
