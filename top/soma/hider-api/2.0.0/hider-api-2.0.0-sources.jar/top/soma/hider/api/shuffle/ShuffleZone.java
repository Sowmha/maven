package top.soma.hider.api.shuffle;

import java.util.Collection;

import org.bukkit.entity.Player;

import top.soma.hider.api.zone.HiderZone;

/**
 * Handle to an open shuffle zone: inside, each member of a group appears to the others under the
 * real identity of another member of the same group. Call from the main thread.
 */
public interface ShuffleZone extends HiderZone {

    ShuffleScope scope();

    /** Groups with at least two members, the only ones shuffled. */
    Collection<ShuffleGroup> groups();

    /** The group with this key, or {@code null}. */
    ShuffleGroup group(String key);

    /** The group of this player, or {@code null} when he has none or it is too small to shuffle. */
    ShuffleGroup groupOf(Player player);

    /** Draws every group again, pinned leases excepted. */
    void redraw();

    /** Reads this player's group again now instead of at the next read. */
    void regroup(Player player);

    /** Tells the zone a group key changed, keeping its members and their leases. */
    void rename(String from, String to);
}
