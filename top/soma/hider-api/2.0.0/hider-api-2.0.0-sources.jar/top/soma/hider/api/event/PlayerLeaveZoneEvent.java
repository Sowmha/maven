package top.soma.hider.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;

import top.soma.hider.api.zone.HiderZone;

/**
 * Fired on the main thread when SomaHider stops covering a player in a zone. A player who goes straight
 * from one zone to another leaves the first before entering the second.
 */
public final class PlayerLeaveZoneEvent extends PlayerEvent {
    private static final HandlerList HANDLERS = new HandlerList();

    /** Why the player left the zone. */
    public enum Cause {
        /** They walked or teleported out, or respawned outside. */
        MOVED,
        /** They disconnected. */
        QUIT,
        /** The zone closed around them. */
        ZONE_CLOSED
    }

    private final HiderZone zone;
    private final Cause cause;

    public PlayerLeaveZoneEvent(Player player, HiderZone zone, Cause cause) {
        super(player);
        this.zone = zone;
        this.cause = cause;
    }

    /** The zone the player left. */
    public HiderZone getZone() {
        return zone;
    }

    public Cause getCause() {
        return cause;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
