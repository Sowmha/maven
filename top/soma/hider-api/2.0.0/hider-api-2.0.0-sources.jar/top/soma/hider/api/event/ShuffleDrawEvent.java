package top.soma.hider.api.event;

import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import top.soma.hider.api.shuffle.ShuffleDraw;
import top.soma.hider.api.shuffle.ShuffleZone;

/**
 * Fired on the main thread before the leases of a shuffle draw change. Listeners may replace the
 * proposed leases or cancel the change, in which case every current lease stays.
 */
public final class ShuffleDrawEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    /** Why the leases are about to change. */
    public enum Cause {
        /** The zone started, or the group became large enough to shuffle. */
        START,
        /** A redraw was asked by a command or the API. */
        REDRAW,
        /** The zone's redraw period elapsed. */
        TIMER,
        /** A member without a lease joined the group or came online. */
        ARRIVAL,
        /** A member left the group. */
        DEPARTURE,
        /** A plugin assigned, swapped or applied leases. */
        API
    }

    private final ShuffleDraw draw;
    private final Cause cause;
    private final Set<UUID> holders;
    private final Set<UUID> identities;
    private Map<UUID, UUID> leases;
    private boolean cancelled;

    public ShuffleDrawEvent(ShuffleDraw draw, Cause cause, Set<UUID> holders, Set<UUID> identities, Map<UUID, UUID> leases) {
        this.draw = draw;
        this.cause = cause;
        this.holders = Set.copyOf(holders);
        this.identities = Set.copyOf(identities);
        this.leases = Map.copyOf(leases);
    }

    public ShuffleDraw getDraw() {
        return draw;
    }

    public ShuffleZone getZone() {
        return draw.group().zone();
    }

    public Cause getCause() {
        return cause;
    }

    /** Proposed leases after the change, member to worn identity. */
    public Map<UUID, UUID> getLeases() {
        return leases;
    }

    /**
     * Replaces the proposal. Every lease holder must get a distinct identity of the group.
     *
     * @throws IllegalArgumentException when a holder is missing, unknown or shares an identity
     */
    public void setLeases(Map<UUID, UUID> leases) {
        Objects.requireNonNull(leases, "leases");
        if (!leases.keySet().equals(holders)) {
            throw new IllegalArgumentException("leases must cover exactly the holders " + holders);
        }
        Set<UUID> worn = new HashSet<>();
        for (UUID identity : leases.values()) {
            if (identity == null || !identities.contains(identity)) {
                throw new IllegalArgumentException(identity + " is not a member of the group");
            }
            if (!worn.add(identity)) {
                throw new IllegalArgumentException(identity + " is worn twice");
            }
        }
        this.leases = Map.copyOf(leases);
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
