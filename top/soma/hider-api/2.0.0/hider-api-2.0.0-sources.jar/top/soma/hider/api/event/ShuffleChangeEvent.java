package top.soma.hider.api.event;

import java.util.Map;
import java.util.UUID;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import top.soma.hider.api.shuffle.ShuffleDraw;
import top.soma.hider.api.shuffle.ShuffleZone;

/** Fired on the main thread after the leases of a shuffle draw changed. Viewers start switching on the next visibility pass. */
public final class ShuffleChangeEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();

    private final ShuffleDraw draw;
    private final ShuffleDrawEvent.Cause cause;
    private final Map<UUID, UUID> before;
    private final Map<UUID, UUID> after;

    public ShuffleChangeEvent(ShuffleDraw draw, ShuffleDrawEvent.Cause cause, Map<UUID, UUID> before, Map<UUID, UUID> after) {
        this.draw = draw;
        this.cause = cause;
        this.before = Map.copyOf(before);
        this.after = Map.copyOf(after);
    }

    public ShuffleDraw getDraw() {
        return draw;
    }

    public ShuffleZone getZone() {
        return draw.group().zone();
    }

    public ShuffleDrawEvent.Cause getCause() {
        return cause;
    }

    /** Leases before the change, member to worn identity. */
    public Map<UUID, UUID> getBefore() {
        return before;
    }

    /** Leases after the change, member to worn identity. */
    public Map<UUID, UUID> getAfter() {
        return after;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
