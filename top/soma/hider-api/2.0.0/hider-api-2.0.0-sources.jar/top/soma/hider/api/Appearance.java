package top.soma.hider.api;

import java.util.UUID;

/**
 * What one viewer sees of a player, in any zone mode.
 *
 * @param kind how the player is shown
 * @param name name shown above the body
 * @param uuid UUID of the shown identity: the player himself, or the worn member; {@code null} for a disguise
 */
public record Appearance(Kind kind, String name, UUID uuid) {

    /** How a player is shown. */
    public enum Kind {
        /** As himself. */
        REAL,
        /** Behind a hider disguise. */
        DISGUISED,
        /** Wearing the identity of another member of his group. */
        SHUFFLED
    }
}
