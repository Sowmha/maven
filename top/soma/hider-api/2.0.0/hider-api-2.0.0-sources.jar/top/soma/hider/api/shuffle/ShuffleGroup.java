package top.soma.hider.api.shuffle;

import java.util.Collection;
import java.util.Set;
import java.util.UUID;

import org.bukkit.entity.Player;

/** A group as one shuffle zone sees it. Call from the main thread. */
public interface ShuffleGroup {

    ShuffleZone zone();

    /** Current group key, as read from the zone's group source. */
    String key();

    /** Every member seen in this group since the server started, online or not. */
    Collection<ShuffleIdentity> members();

    /** Members holding a lease in this zone. A lease outlives a disconnect until the zone ends. */
    Set<UUID> holders();

    /** Draws made so far, one per audience. */
    Collection<ShuffleDraw> draws();

    /** The draw seen by this viewer's audience. Reveal rules may still show some members as themselves. */
    ShuffleDraw draw(Player viewer);

    /** The draw of this audience key, made on first use. */
    ShuffleDraw draw(String audience);

    /** Draws every audience of this group again, pinned leases excepted. */
    void redraw();
}
