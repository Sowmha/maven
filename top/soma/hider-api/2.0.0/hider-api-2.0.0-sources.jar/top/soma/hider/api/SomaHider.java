package top.soma.hider.api;

import java.util.Collection;

import org.bukkit.entity.Player;

import top.soma.hider.api.shuffle.ShuffleBuilder;
import top.soma.hider.api.zone.HiderZone;
import top.soma.hider.api.zone.Region;
import top.soma.hider.api.zone.ZoneBuilder;

/**
 * Entry point for hiding players inside zones.
 *
 * <pre>{@code
 * HiderZone zone = SomaHiderProvider.get()
 *         .hide(arena::contains)
 *         .groupResolver(player -> factionId(player))
 *         .reveal(Reveal.sameGroup())
 *         .open();
 * // ...later
 * zone.close();
 * }</pre>
 */
public interface SomaHider {

    /** Begins a zone that covers the whole server. */
    ZoneBuilder hide();

    /** Begins a zone bounded by {@code region}. */
    ZoneBuilder hide(Region region);

    /** Begins a shuffle zone that covers the whole server. */
    ShuffleBuilder shuffle();

    /**
     * Begins a shuffle zone bounded by {@code region}: members of a group swap their real
     * identities in the eyes of everyone else.
     */
    ShuffleBuilder shuffle(Region region);

    /** A snapshot of the currently open zones. */
    Collection<HiderZone> zones();

    /** What {@code viewer} sees of {@code target} right now. Call from the main thread. */
    Appearance appearance(Player viewer, Player target);

    /**
     * Re-evaluates every visibility rule right away instead of waiting for the next
     * periodic pass. Call this after flipping an external reveal condition (a faction
     * starts capturing a KoTH, a duel starts, ...) so the swap lands on the same tick.
     *
     * <p>Safe to call from any thread; off the main thread it schedules for the
     * current tick.
     */
    void refresh();
}
