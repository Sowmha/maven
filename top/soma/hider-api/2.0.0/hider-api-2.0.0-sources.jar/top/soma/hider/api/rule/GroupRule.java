package top.soma.hider.api.rule;

import org.bukkit.entity.Player;

record GroupRule(VisibilityRule rule, boolean targetByGroup) implements VisibilityRule {

    @Override
    public boolean reveals(Player viewer, Player target, RuleContext context) {
        return rule.reveals(viewer, target, context);
    }

    static VisibilityRule keep(VisibilityRule source, VisibilityRule composed) {
        return source instanceof GroupRule grouped ? new GroupRule(composed, grouped.targetByGroup) : composed;
    }

    static VisibilityRule keep(VisibilityRule first, VisibilityRule second, VisibilityRule composed) {
        if (first instanceof GroupRule a && second instanceof GroupRule b) {
            return new GroupRule(composed, a.targetByGroup && b.targetByGroup);
        }
        return composed;
    }
}
