package top.soma.hider.api.shuffle;

import java.time.Duration;

import org.bukkit.configuration.ConfigurationSection;

import top.soma.hider.api.disguise.DisguiseProfile;
import top.soma.hider.api.hook.GroupResolver;
import top.soma.hider.api.rule.VisibilityRule;

/**
 * Fluent description of a shuffle zone. Terminal call is {@link #open()}.
 *
 * <p>Members of a group always see each other as they are. A viewer outside the group sees each
 * member wearing the identity of another member, unless any of the reveal rules matches.
 */
public interface ShuffleBuilder {

    /** Optional name (defaults to an auto-generated one). */
    ShuffleBuilder named(String name);

    /** Auto-close the zone after this delay. */
    ShuffleBuilder duration(Duration duration);

    /** How players map to a group key. Players without a group are never shuffled. */
    ShuffleBuilder groupResolver(GroupResolver resolver);

    /** Reveal rules combined with OR: a match shows the member as himself. */
    ShuffleBuilder reveal(VisibilityRule... rules);

    /** Which viewers share a draw. Defaults to {@link ShuffleScope#shared()}. */
    ShuffleBuilder scope(ShuffleScope scope);

    /** Draws every group again at this period. {@code null} draws only at start and on request. */
    ShuffleBuilder redrawEvery(Duration period);

    /** Look of players without a group. {@code null}, the default, shows them as themselves. */
    ShuffleBuilder ungrouped(DisguiseProfile disguise);

    /** What the body of a shuffled member shows: armor, item details, fire, arrows, invisibility. */
    ShuffleBuilder body(DisguiseProfile body);

    /** Same as {@link #body(DisguiseProfile)}, read from a config section over the configured default. */
    ShuffleBuilder body(ConfigurationSection section);

    /**
     * Prefix shown before the worn name, {@code {prefix}} by default. {@code {prefix}} is the worn member's own
     * prefix as the viewer sees it; it is shortened when the whole would exceed 16 characters. Supports
     * {@code &} colors and placeholders resolved on the wearer. {@code null} restores the default.
     */
    ShuffleBuilder prefix(String format);

    /** Suffix shown after the worn name, {@code {suffix}} by default. Same rules as {@link #prefix(String)}. */
    ShuffleBuilder suffix(String format);

    /**
     * Opens the zone and returns its handle. Call from the main thread.
     *
     * @throws IllegalStateException off the main thread
     */
    ShuffleZone open();
}
