package top.soma.hider.api.event;

import java.util.UUID;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired on the main thread when a shuffle group changes, as read from a group source while a shuffle
 * zone runs. Zones sharing a source share the change.
 */
public final class ShuffleGroupEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();

    /** What happened to the group. */
    public enum Kind {
        /** A player joined the group. */
        JOIN,
        /** A player left the group. */
        LEAVE,
        /** The group key changed, members and leases kept. */
        RENAME,
        /** Every online member left at once: the group is gone. */
        DISSOLVE
    }

    private final Kind kind;
    private final String key;
    private final String previousKey;
    private final UUID player;

    public ShuffleGroupEvent(Kind kind, String key, String previousKey, UUID player) {
        this.kind = kind;
        this.key = key;
        this.previousKey = previousKey;
        this.player = player;
    }

    public Kind getKind() {
        return kind;
    }

    /** Group key after the change, or the dissolved group's key. */
    public String getKey() {
        return key;
    }

    /** Key before a {@link Kind#RENAME}, {@code null} otherwise. */
    public String getPreviousKey() {
        return previousKey;
    }

    /** Player who joined or left, {@code null} for a rename or a dissolution. */
    public UUID getPlayer() {
        return player;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
