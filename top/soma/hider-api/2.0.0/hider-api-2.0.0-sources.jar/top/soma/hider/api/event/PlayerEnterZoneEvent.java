package top.soma.hider.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;

import top.soma.hider.api.zone.HiderZone;

/**
 * Fired on the main thread when SomaHider starts covering a player in a zone: they walked or teleported
 * in, joined or respawned inside, or the zone opened around them. A teleport is announced before the
 * player arrives, so that nobody sees them unmasked on the way in. Every enter is later matched by a
 * {@link PlayerLeaveZoneEvent} for the same zone.
 */
public final class PlayerEnterZoneEvent extends PlayerEvent {
    private static final HandlerList HANDLERS = new HandlerList();

    private final HiderZone zone;

    public PlayerEnterZoneEvent(Player player, HiderZone zone) {
        super(player);
        this.zone = zone;
    }

    /** The zone now covering the player. */
    public HiderZone getZone() {
        return zone;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
