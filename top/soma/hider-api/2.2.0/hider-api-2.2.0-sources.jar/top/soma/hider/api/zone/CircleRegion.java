package top.soma.hider.api.zone;

import java.util.Objects;

import org.bukkit.Location;
import org.bukkit.World;

final class CircleRegion implements Region {

    private final String world;
    private final double centerX;
    private final double centerZ;
    private final double radiusSquared;

    CircleRegion(Location center, double radius) {
        this.world = Objects.requireNonNull(center.getWorld(), "world").getName();
        this.centerX = center.getX();
        this.centerZ = center.getZ();
        this.radiusSquared = radius * radius;
    }

    @Override
    public boolean contains(Location location) {
        World at = location == null ? null : location.getWorld();
        if (at == null || !world.equals(at.getName())) {
            return false;
        }
        double dx = location.getX() - centerX;
        double dz = location.getZ() - centerZ;
        return dx * dx + dz * dz <= radiusSquared;
    }
}
