package top.soma.hider.api.shuffle;

import org.bukkit.entity.Player;

import top.soma.hider.api.rule.RuleContext;

/**
 * Decides which viewers share a draw: viewers given the same key see the same identities.
 * <pre>{@code
 * ShuffleScope.perGroup()
 * }</pre>
 *
 * <p>The built-in scopes use the keys {@code ""} (shared), {@code "group:<id>"} (per group) and
 * {@code "viewer:<uuid>"} (per viewer), as {@link ShuffleDraw#audience()} shows them. A {@code null}
 * key, or an exception, gives the shared draw; an exception is logged once per scope class.
 */
@FunctionalInterface
public interface ShuffleScope {

    /** Key of the draw this viewer sees. Viewers with equal keys share it. */
    String audienceOf(Player viewer, RuleContext context);

    /** One draw for everyone. */
    static ShuffleScope shared() {
        return Scopes.SHARED;
    }

    /** One draw per group of viewers. Viewers without a group share one. */
    static ShuffleScope perGroup() {
        return Scopes.PER_GROUP;
    }

    /** One draw per viewer. */
    static ShuffleScope perViewer() {
        return Scopes.PER_VIEWER;
    }

    /** Whether two viewers of the same group always share a draw under this scope. */
    static boolean sharedByGroup(ShuffleScope scope) {
        return scope == Scopes.SHARED || scope == Scopes.PER_GROUP;
    }
}
