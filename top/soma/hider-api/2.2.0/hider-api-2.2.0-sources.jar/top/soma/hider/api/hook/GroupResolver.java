package top.soma.hider.api.hook;

import org.bukkit.entity.Player;

/**
 * Maps a player to the group id that a zone's group rules compare.
 *
 * <p>Called on the main thread. In a hide zone the answer is kept for up to a second per player, and
 * {@link top.soma.hider.api.SomaHider#refresh()} asks again right away. In a shuffle zone every online
 * player is asked once a second, and {@link top.soma.hider.api.shuffle.ShuffleZone#regroup(Player)}
 * asks again for one player.
 *
 * <p>{@code null}, a blank id and a thrown exception all mean "no group". An exception is logged once
 * per resolver class.
 */
@FunctionalInterface
public interface GroupResolver {

    String groupOf(Player player);
}
