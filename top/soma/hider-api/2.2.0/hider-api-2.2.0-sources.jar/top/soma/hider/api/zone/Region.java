package top.soma.hider.api.zone;

import org.bukkit.Location;

/**
 * The volume a zone covers. It is a {@link FunctionalInterface}, so any
 * {@code boolean contains(Location)} method reference works as a region —
 * e.g. {@code arena::isInArea}.
 *
 * <p>Called on the main thread every pass, and on the PlaceholderAPI thread for the
 * {@code %somahider_zone%} family of placeholders, which TAB may resolve asynchronously:
 * keep it cheap and thread-safe.
 */
@FunctionalInterface
public interface Region {

    boolean contains(Location location);

    /** A horizontal disc of {@code radius} centered on {@code center} (ignores Y). */
    static Region circle(Location center, double radius) {
        return new CircleRegion(center, radius);
    }
}
