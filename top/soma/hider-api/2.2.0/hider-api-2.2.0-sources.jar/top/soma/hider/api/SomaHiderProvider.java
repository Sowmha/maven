package top.soma.hider.api;

/** Where other plugins find the running {@link SomaHider}. */
public final class SomaHiderProvider {

    private static volatile SomaHider instance;

    private SomaHiderProvider() {
        throw new UnsupportedOperationException("You can't instantiate this class.");
    }

    /**
     * Makes {@code hider} the instance {@link #get()} returns. SomaHider calls it when it enables.
     *
     * @throws IllegalStateException if an instance is already registered
     */
    public static void register(SomaHider hider) {
        if (instance != null) {
            throw new IllegalStateException("SomaHider is already registered by " + instance.getClass().getName() + "; the previous implementation never unregistered itself.");
        }
        instance = hider;
    }

    /** Clears the registered instance for every plugin at once. SomaHider calls it when it disables. */
    public static void unregister() {
        instance = null;
    }

    /**
     * The running SomaHider.
     *
     * @throws IllegalStateException if SomaHider is not loaded
     */
    public static SomaHider get() {
        if (instance == null) {
            throw new IllegalStateException("SomaHider is not loaded yet. Install SomaHider and add it to depend in your plugin.yml.");
        }
        return instance;
    }

    /** The running SomaHider, or {@code null} when it is not loaded. */
    public static SomaHider getOrNull() {
        return instance;
    }

    /** Whether SomaHider is loaded. */
    public static boolean isAvailable() {
        return instance != null;
    }
}
