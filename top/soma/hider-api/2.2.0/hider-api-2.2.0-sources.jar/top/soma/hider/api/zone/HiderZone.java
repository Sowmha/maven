package top.soma.hider.api.zone;

/** Handle to an open zone. Call {@link #close()} to take it down. */
public interface HiderZone {

    String name();

    /** Takes the zone down. Safe to call from any thread: off the main thread, the zone closes at the next tick, before anyone is announced leaving it. */
    void close();
}
