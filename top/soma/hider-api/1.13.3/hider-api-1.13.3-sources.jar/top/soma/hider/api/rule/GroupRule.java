package top.soma.hider.api.rule;

import org.bukkit.entity.Player;

record GroupRule(VisibilityRule rule) implements VisibilityRule {

    @Override
    public boolean reveals(Player viewer, Player target, RuleContext context) {
        return rule.reveals(viewer, target, context);
    }

    static VisibilityRule keep(VisibilityRule source, VisibilityRule composed) {
        return source instanceof GroupRule ? new GroupRule(composed) : composed;
    }

    static VisibilityRule keep(VisibilityRule first, VisibilityRule second, VisibilityRule composed) {
        return first instanceof GroupRule && second instanceof GroupRule ? new GroupRule(composed) : composed;
    }
}
