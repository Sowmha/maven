package top.soma.hider.api.rule;

import java.util.Collection;
import java.util.Objects;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import java.util.function.Supplier;

import org.bukkit.entity.Player;

/**
 * Ready-made {@link VisibilityRule}s. Combine them with {@code or}/{@code and}/{@code negate}:
 * <pre>{@code
 * Reveal.sameGroup().or(Reveal.group(() -> capturingFactionId))
 * }</pre>
 */
public final class Reveal {

    private Reveal() {
        throw new UnsupportedOperationException("You can't instantiate this class.");
    }

    /** Reveal a target that shares the viewer's group. */
    public static VisibilityRule sameGroup() {
        return byGroup((viewer, target, context) -> {
            String group = context.groupOf(viewer);
            return group != null && group.equals(context.groupOf(target));
        });
    }

    /** Reveal every member of {@code groupId} to everyone. */
    public static VisibilityRule group(String groupId) {
        Objects.requireNonNull(groupId, "groupId");
        return byGroup((viewer, target, context) -> groupId.equals(context.groupOf(target)));
    }

    /** Reveal every member of the group to everyone (live). */
    public static VisibilityRule group(Supplier<String> groupId) {
        Objects.requireNonNull(groupId, "groupId");
        return byGroup((viewer, target, context) -> {
            String id = context.once(groupId);
            return id != null && id.equals(context.groupOf(target));
        });
    }

    /** Reveal members of the set of groups to one another (live). Viewer and target must both be in it. */
    public static VisibilityRule groupsTogether(Supplier<? extends Collection<String>> groups) {
        Objects.requireNonNull(groups, "groups");
        return byGroup((viewer, target, context) -> {
            Collection<String> ids = context.once(groups);
            if (ids == null || ids.isEmpty()) {
                return false;
            }
            String viewerGroup = context.groupOf(viewer);
            String targetGroup = context.groupOf(target);
            return viewerGroup != null && targetGroup != null && ids.contains(viewerGroup) && ids.contains(targetGroup);
        });
    }

    /** Reveal everyone to viewers holding {@code node}. */
    public static VisibilityRule permission(String node) {
        Objects.requireNonNull(node, "node");
        return (viewer, target, context) -> context.hasPermission(viewer, node);
    }

    /** Reveal every target matching {@code predicate}, whoever is looking. */
    public static VisibilityRule target(Predicate<Player> predicate) {
        Objects.requireNonNull(predicate, "predicate");
        return byGroup((viewer, target, context) -> predicate.test(target));
    }

    /**
     * Escape hatch: any predicate over (viewer, target). Since the plugin cannot know what the predicate
     * reads, a zone holding one evaluates its rules for every viewer separately. Prefer {@link #target}
     * when the answer does not depend on who is looking.
     */
    public static VisibilityRule of(BiPredicate<Player, Player> predicate) {
        Objects.requireNonNull(predicate, "predicate");
        return (viewer, target, context) -> predicate.test(viewer, target);
    }

    public static VisibilityRule never() {
        return byGroup((viewer, target, context) -> false);
    }

    /**
     * Whether the plugin can decide {@code rule} once for a whole group instead of once per viewer.
     * True for every rule built here except {@link #permission} and {@link #of}, and for any composition
     * of those; false for a hand-written rule, whose reads the plugin cannot see. Nothing to set and
     * nothing to get wrong - it is read off the rules themselves.
     */
    public static boolean sharedByGroup(VisibilityRule rule) {
        return rule instanceof GroupRule;
    }

    private static VisibilityRule byGroup(VisibilityRule rule) {
        return new GroupRule(rule);
    }
}
